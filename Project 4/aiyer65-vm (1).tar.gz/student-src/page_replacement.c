#include "types.h"
#include "pagesim.h"
#include "paging.h"
#include "swapops.h"
#include "stats.h"

pfn_t select_victim_frame(void);

/*  --------------------------------- PROBLEM 7 --------------------------------------
    Finds a free physical frame. If none are available, uses a clock sweep
    algorithm to find a used frame for eviction.

    Make sure you set the reference bits to 0 for each frame that had its
    referenced bit set.

    Return:
        The physical frame number of a free (or evictable) frame.

    HINTS: Use the global variables MEM_SIZE and PAGE_SIZE to calculate
    the number of entries in the frame table.
    ----------------------------------------------------------------------------------
*/
pfn_t select_victim_frame() {
    /* See if there are any free frames */
    int i;
    fte_t* my_entry;
    pcb_t* my_proc;
    pte_t* my_page;

    for (i = 1; i < NUM_FRAMES; i++){
        if(frame_table[i].protected != 1 && frame_table[i].mapped != 1){// not protected or mapped
            return i;
        }
    }

    /* Implement a clock sweep algorithm here */
    for(i=1; i< NUM_FRAMES; i++) {
        my_entry = frame_table + i;
        if (my_entry->protected == 0) {
            if (my_entry->referenced == 0) {
                return i;
            } else {
                my_entry->referenced = 0;
            }
        }
    }

    /*
     * Cycled all the way through and all reference bits were set.
     * So loop back and return the first entry that is not protected.
     */
    for(i=1; i< NUM_FRAMES; i++) {
        my_entry = frame_table + i;
        if (!my_entry->protected){
            return i;
        }
    }

    /* If every frame is protected, give up. This should never happen
       on the traces we provide you. */
    printf("System ran out of memory\n");
    exit(1);
}

/*  --------------------------------- PROBLEM 8 --------------------------------------
    Make a free frame for the system to use.

    You will first call your page replacement algorithm to identify an
    "available" frame in the system.

    In some cases, the replacement algorithm will return a frame that
    is in use by another page mapping. In these cases, you must "evict"
    the frame by using the frame table to find the original mapping and
    setting it to invalid. If the frame is dirty, write its data to swap!
 * ----------------------------------------------------------------------------------
 */
pfn_t free_frame(void) {
    pfn_t victim_pfn;

    /* Call your function to find a frame to use, either one that is
       unused or has been selected as a "victim" to take from another
       mapping. */
    victim_pfn = select_victim_frame();

    /*
     * If victim frame is currently mapped:
     *
     * 1) Look up the corresponding page table entry
     * 2) If the entry is dirty, write it to disk with swap_write()
     * 3) Mark the original page table entry as invalid
     */
    if (frame_table[victim_pfn].mapped){
        pfn_t ptbr_index = frame_table[victim_pfn].process->saved_ptbr;
        pte_t* corresponding_pte = ((pte_t *) (mem + (ptbr_index * PAGE_SIZE))) + (frame_table[victim_pfn].vpn);
        if (corresponding_pte->dirty){
            swap_write(corresponding_pte, mem + (victim_pfn * PAGE_SIZE));
            stats.writebacks += 1;
            corresponding_pte->dirty = 0;
        }
        corresponding_pte->valid = 0;
    }

    frame_table[victim_pfn].mapped = 0;
    frame_table[victim_pfn].process = NULL;
    frame_table[victim_pfn].vpn = 0;
    frame_table[victim_pfn].referenced = 0;

    return victim_pfn;
}
