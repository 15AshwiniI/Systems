#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include "buffer.h"

/**************************************************************************\
 *                                                                        *
 * Bounded buffer.  This is the only part you need to modify.  Your       *
 * buffer should have space for up to 10 integers in it at a time.        *
 *                                                                        *
 * Add any data structures you need (globals are fine) and fill in        *
 * implementations for these three procedures:                            *
 *                                                                        *
\**************************************************************************/

typedef struct node {
	int data;
	struct node *next;
} node_t;

typedef struct linked_list {
	node_t *head;
    node_t *tail;
	int curr_size;
	int max_size;
} linked_list_t;

typedef struct array {
    int *items;
    int size;
} array_t;

// TODO: INSTANTIATE GLOBALS
linked_list_t myBuffer;
array_t myArray;
pthread_mutex_t lock;
pthread_mutex_t arrayLock;
pthread_cond_t BUFFER_NOT_FULL;
pthread_cond_t BUFFER_NOT_EMPTY;
pthread_cond_t VALUE_AVAILABLE;

/**************************************************************************\
 *                                                                        *
 * void buffer_init(void)                                                 *
 *                                                                        *
 *      buffer_init() is called by main() at the beginning of time to     *
 *      perform any required initialization.  I.e. initialize the buffer, *
 *      any mutex/condition variables, etc.                               *
 *                                                                        *
\**************************************************************************/
void buffer_init()
{
    // TODO: IMPLEMENT METHOD

    //Set up buffer
    myBuffer.max_size = 10;
    myBuffer.curr_size = 0;
    myBuffer.head = NULL; //maybe need to set data to Null and next to something?
    myBuffer.tail = NULL; //does this set all the values to NUll?

    //currentNode = myBuffer.head;
    //Set up array to avoid doubles
    myArray.items = calloc(10, sizeof(int));
    myArray.size = 10;

    //set up conditions
    /*BUFFER_NOT_FULL =*/ pthread_cond_init(&BUFFER_NOT_FULL, NULL);
    /*BUFFER_NOT_EMPTY = */pthread_cond_init(&BUFFER_NOT_EMPTY, NULL);
    /*BUFFER_NOT_EMPTY = */pthread_cond_init(&VALUE_AVAILABLE, NULL);

    //Set up lock
    pthread_mutex_init(&lock, NULL);
    pthread_mutex_init(&arrayLock, NULL);

    //return;
}

/**************************************************************************\
 *                                                                        *
 * void buffer_insert(int number)                                         *
 *                                                                        *
 *      buffer_insert() inserts a number into the next available slot in  *
 *      the buffer.  If no slots are available, the thread should wait    *
 *      (not spin-wait!) for an empty slot to become available.           *
 *                                                                        *
\**************************************************************************/
void buffer_insert(int number)
{
    pthread_mutex_lock(&lock);
    //if (number == 0) {
        //pthread_cancel()
        //return;
    //}
    while (myBuffer.curr_size == myBuffer.max_size){
        pthread_cond_wait(&BUFFER_NOT_FULL, &lock);
    }
    node_t *currentNode = (node_t*)malloc(sizeof(node_t));
    currentNode->data = number;
    currentNode->next = NULL;
    if (myBuffer.head == NULL) {
        myBuffer.head = currentNode;
        myBuffer.tail = currentNode;
    } else {
        myBuffer.tail -> next = currentNode;
        myBuffer.tail = currentNode;   
    }
    myBuffer.curr_size += 1;
    pthread_cond_signal(&BUFFER_NOT_EMPTY);
    pthread_mutex_unlock(&lock);
    return;
}

/**************************************************************************\
 *                                                                        *
 * int buffer_extract(void)                                               *
 *                                                                        *
 *      buffer_extract() removes and returns the number in the next       *
 *      available slot.  If no number is available, the thread should     *
 *      wait (not spin-wait!) for a number to become available.  Note     *
 *      that multiple consumers may call buffer_extract() simulaneously.  *
 *                                                                        *
\**************************************************************************/
int buffer_extract(void)
{
    // TODO: IMPLEMENT METHOD (NOTE: THIS METHOD MUST CALL process(int number) before returning the number)
    pthread_mutex_lock(&lock);
    while (myBuffer.curr_size == 0){
        pthread_cond_wait(&BUFFER_NOT_EMPTY, &lock);
    }
    int value = myBuffer.head->data;
    node_t *temp = myBuffer.head;
    myBuffer.head = myBuffer.head->next;
    myBuffer.curr_size -= 1;
    pthread_cond_signal(&BUFFER_NOT_FULL);
    pthread_mutex_unlock(&lock);
    free(temp);

    pthread_mutex_lock(&arrayLock);
    while (myArray.items[value-1] == 1) {
	pthread_cond_wait(&VALUE_AVAILABLE, &arrayLock);
    }
    myArray.items[value-1] = 1;
//unlock
    pthread_mutex_unlock(&arrayLock);
    process(value);
//lock
    pthread_mutex_lock(&arrayLock);
    myArray.items[value-1] = 0;
    pthread_cond_signal(&VALUE_AVAILABLE);
    pthread_mutex_unlock(&arrayLock);

    return value;
}

void process(int number) {
    sleep(number);
}
