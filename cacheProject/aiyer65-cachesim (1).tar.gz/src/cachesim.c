#include "cachesim.h"

#define TRUE 1
#define FALSE 0

/**
 * The stuct that you may use to store the metadata for each block in
 * the cache
 */
typedef struct {
    uint64_t tag;  // The tag stored in that block
    uint8_t valid; // Valid bit
    uint8_t dirty; // Dirty bit
    unsigned lru; // LRU counter
    unsigned fifo; // FIFO counter

    // Add any metadata here to perform LRU/FIFO replacement. For LRU,
    // think about how you could use a counter variable to track the
    // oldest block in a set. For FIFO, consider how you would
    // implement a queue with only a single pointer.

    // TODO

} block_t;

/**
 * A struct for storing the configuration of the cache as passed in
 * the cache_init function.
 */
typedef struct config {
    uint64_t C;
    uint64_t B;
    uint64_t S;
    enum REPLACEMENT_POLICY policy;
} config_t;

// You may add global variables, structs, and function headers below
// this line if you need any

// TODO


typedef struct {
    block_t* blocks;
} cacheSet;

typedef struct {
    cacheSet* sets;
} cache;

int LRU_increment = 0;
int FIFO_increment = 0;
uint64_t numSets; //number of sets
uint64_t numBlocks; //number of blocks
cache currentCache;
config_t myConfig;



/**
 * Initializes your cache with the passed in arguments.
 *
 * @param C The total size of your cache is 2^C bytes
 * @param S The total number of blocks in a line/set of your cache are 2^S
 * @param B The size of your blocks is 2^B bytes
 * @param policy The replacement policy of your cache
 */
void cache_init(uint64_t C, uint64_t B, uint64_t S, enum REPLACEMENT_POLICY policy)
{
    // Initialize the cache here. We strongly suggest using arrays for
    // the cache meta data. The block_t struct given above may be
    // useful.

    // TODO
    //return NULL;
    int block_i, set_i;
    myConfig.C = C;
    myConfig.B = B;
    myConfig.S = S;
    myConfig.policy = policy;
    block_t myBlock;
    cacheSet mySet;
    uint64_t one = 1;
    numSets = one<<(C-B-S);
    numBlocks = one<<S; 
    currentCache.sets = (cacheSet*) malloc(numSets*sizeof(cacheSet));
    for (set_i = 0; set_i < numSets; set_i++) {
        mySet.blocks = (block_t*) malloc(numBlocks * sizeof(block_t));
        currentCache.sets[set_i] = mySet;
        for (block_i = 0; block_i < numBlocks; block_i++){
            myBlock.lru = 0;
            myBlock.fifo = 0;
            myBlock.valid = 0;
            myBlock.dirty = 0;
            myBlock.tag = 0;
            mySet.blocks[block_i] = myBlock;
        }
    }
}



int return_emptyLine(cacheSet* mySet){
    int i;
    for (i = 0; i < numBlocks; i++){
        if (mySet->blocks[i].valid == 0){
            return i;
        }
    }
    return -1;
}

int return_evictedLine(cacheSet* mySet){
    int minimumIndex = 0;
    if (myConfig.policy == LRU){
        int minimumVal = mySet->blocks[0].lru;
        for(int i=1; i< numBlocks; i++){
            int possibleVal = mySet->blocks[i].lru;
            if (possibleVal < minimumVal){
                minimumVal = possibleVal;
                minimumIndex = i;
            }
        }
    } else{
        int minimumVal = mySet->blocks[0].fifo;
        for(int i=1; i<numBlocks; i++){
            int possibleVal = mySet->blocks[i].fifo;
            if (possibleVal < minimumVal){
                minimumVal = possibleVal;
                minimumIndex = i;
            }
        }
    }
    return minimumIndex;
}

/**
 * Simulates one cache access at a time.
 *
 * @param rw The type of access, READ or WRITE
 * @param address The address that is being accessed
 * @param stats The struct that you are supposed to store the stats in
 * @return TRUE if the access is a hit, FALSE if not
 */
uint8_t cache_access(char rw, uint64_t address, cache_stats_t* stats)
{

    uint8_t is_hit = FALSE;
    if(rw=='r') stats->reads+=1;
    else stats->writes+=1;
    stats->accesses+=1;

    // TODO
    int hitFoundCounter = 0;
    int fullSet = 1; 
    int blockIndex;
    uint64_t tag = get_tag(address, myConfig.C, myConfig.B, myConfig.S);
    uint64_t set_i = get_index(address, myConfig.C, myConfig.B, myConfig.S);
    cacheSet currentSet = currentCache.sets[set_i];

    for (blockIndex = 0; blockIndex < numBlocks; blockIndex++){
        block_t currentBlock = currentSet.blocks[blockIndex];
        if (currentBlock.valid && (tag == currentBlock.tag)){
            LRU_increment += 1;
            currentBlock.lru = LRU_increment;
            if(rw=='w') currentBlock.dirty = 1;
            currentCache.sets[set_i].blocks[blockIndex] = currentBlock;
            hitFoundCounter = 1;
            return TRUE;
        }
        else if ((fullSet)&&(currentBlock.valid == 0)){
            fullSet = 0;
        }
    }

    if(!fullSet){
        int blockToAddTo = return_emptyLine(&currentSet);
        currentSet.blocks[blockToAddTo].tag = tag;
        currentSet.blocks[blockToAddTo].valid = 1;
        if (rw=='w') {
            currentSet.blocks[blockToAddTo].dirty = 1;
        }
        else {
            currentSet.blocks[blockToAddTo].dirty = 0;
        }

        if (myConfig.policy == LRU){
            LRU_increment += 1;
            currentSet.blocks[blockToAddTo].lru = LRU_increment;
        } else{
            FIFO_increment += 1;
            currentSet.blocks[blockToAddTo].fifo = FIFO_increment;
        }
    } else{ // This condition handles eviction if the set is full.
        int blockToBeEvicted = return_evictedLine(&currentSet);
        currentSet.blocks[blockToBeEvicted].tag = tag;
        if (currentSet.blocks[blockToBeEvicted].dirty == 1){ 
            stats->write_backs += 1;
        }
        if (rw=='w') {
            currentSet.blocks[blockToBeEvicted].dirty = 1;
        }
        else {
            currentSet.blocks[blockToBeEvicted].dirty = 0;
        }
        if (myConfig.policy == LRU){
            LRU_increment += 1;
            currentSet.blocks[blockToBeEvicted].lru = LRU_increment;
        } else{
            FIFO_increment += 1;
            currentSet.blocks[blockToBeEvicted].fifo = FIFO_increment;
        }
    }

    
    if(!hitFoundCounter){
        stats->misses += 1;
        if (rw=='r'){
            stats->read_misses += 1;
        }  
        else {
            stats->write_misses += 1;
        }
    }

    currentCache.sets[set_i] = currentSet;

    return is_hit;
}

/**
 * Frees up memory and performs any final calculations before the
 * statistics are outputed by the driver
 */
void cache_cleanup(cache_stats_t* stats)
{
    // Make sure to free any malloc'd memory here. To check if you
    // have freed up the the memory, run valgrind. For more
    // information, google how to use valgrind.

    // TODO
    int set_i;
    for (set_i = 0; set_i < numSets; set_i++) {
        cacheSet tempSet = currentCache.sets[set_i];
        if (tempSet.blocks != NULL) {
            free(tempSet.blocks);
        }
    }
    if (currentCache.sets != NULL) {
        free(currentCache.sets);
    }
    stats->miss_rate = (1.0*(stats->misses))/stats->accesses;
    stats->avg_access_time = stats->cache_access_time+stats->memory_access_time*stats->miss_rate; //in ns
}

/**
 * Computes the tag of a given address based on the parameters passed
 * in
 *
 * @param address The address whose tag is to be computed
 * @param C The size of the cache (i.e. Size of cache is 2^C)
 * @param B The size of the cache block (i.e. Size of block is 2^B)
 * @param S The set associativity of the cache (i.e. Set-associativity is 2^S)
 * @return The computed tag
 */
uint64_t get_tag(uint64_t address, uint64_t C, uint64_t B, uint64_t S)
{
    // TODO
    return address >> (C-S);
}

/**
 * Computes the index of a given address based on the parameters
 * passed in
 *
 * @param address The address whose tag is to be computed
 * @param C The size of the cache (i.e. Size of cache is 2^C)
 * @param B The size of the cache block (i.e. Size of block is 2^B)
 * @param S The set associativity of the cache (i.e. Set-associativity is 2^S)
 * @return The computed index
 */
uint64_t get_index(uint64_t address, uint64_t C, uint64_t B, uint64_t S)
{
    // TODO
    return (((numSets-1) << B) & address) >> B;
}